const s="/assets/770c2281aaeb9096b997178db2b7b818.zGd3Xmug.png";export{s as _};
